var findMyBank = angular.module('findMyBankApp', ['ngRoute']);

findMyBank.config(['$routeProvider', function($routeProvider){
  $routeProvider
  .when('/home', {
    templateUrl: 'views/home.html'
  })
  .when('/directory', {
    templateUrl: 'views/directory.html',
    controller: 'LocationController'
  }).otherwise({
    redirectTo: '/home'
  })

}]);

findMyBank.controller('LocationController', ['$scope', '$http', function($scope, $http){
    $scope.addBank = function(){
      $scope.banks.push({
        name: "$scope.newBank.name",
        address: "$scope.newBank.address",
        cityState: "$scope.newBank.cityState",
        zip: "$scope.newBank.zip",
        saturday: "$scope.newBank.saturday"
      });
      $scope.newBank.name ="";
      $scope.newBank.address ="";
      $scope.newBank.cityState ="";
      $scope.newBank.zip="";
      $scope.newBank.saturday ="";
    };

//    $scope.message = "Your Nearest Bank is:";
    // $http.get('data/banks.json').then(function(data){
    //   $scope.banks = data;
    // });
  $http.get('data/banks.json').then(
                function(data) {
                    $scope.banks = data;
                });
}]);
