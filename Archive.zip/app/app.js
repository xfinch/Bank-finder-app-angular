var findMyBank = angular.module('findMyBankApp', ['ngRoute']);

findMyBank.config(['$routeProvider', function($routeProvider){
  $routeProvider
  .when('/home', {
    templateUrl: 'views/home.html'
  })
  .when('/directory', {
    templateUrl: 'views/directory.html',
    controller: 'LocationController'
  }).otherwise({
    redirectTo: '/home'
  })

}]);

// findMyBankApp.config(function(){
//
// });
//
// findMyBankApp.run(function(){
//
// });

findMyBank.controller('LocationController', ['$scope', function($scope){
    $scope.addBank = function(){
      $scope.banks.push({
        name: "$scope.newBank.name",
        address: "$scope.newBank.address",
        cityState: "$scope.newBank.cityState",
        zip: "$scope.newBank.zip",
        saturday: "$scope.newBank.saturday"
      });
      $scope.newBank.name ="";
      $scope.newBank.address ="";
      $scope.newBank.cityState ="";
      $scope.newBank.zip="";
      $scope.newBank.saturday ="";
    };

    $scope.message = "Your Nearest Bank is:";
    $scope.banks = [
    {
        name:"American First - Kent Station",
        address: "1289 Station DR",
        cityState:"Kent, WA",
        zip:"98032",
        saturday: true
    },
    {
      name:"American First - Downtown Seattle",
      address:"123 Main St",
      cityState: "Seattle, WA",
      zip : "98121",
      saturday: false
    },

    {
      name:"American First - Tacoma",
      address:"2109 Pacific Ave",
      cityState: "Tacoma, WA",
      zip:"98404",
      saturday: true
    },
    {
      name:"American First - Burien",
      address:"15836 1st Ave",
      cityState: "Burien, WA",
      zip:"98148",
      saturday: false
    }

  ];
    console.log(angular.toJson($scope.banks));
}]);
